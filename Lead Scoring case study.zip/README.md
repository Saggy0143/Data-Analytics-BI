# Logistic-Regression-Case-Study-by-Yash-Sahindrakar-and-Sagar-Patil
This is a complete case study on lead scoring analysis giving by X education company.
With accuracy of 81%.
